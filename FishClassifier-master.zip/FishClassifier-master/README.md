# FishClassifier
Fish Classifier is a Machine Learning(Computer Vision) project, Which shall be able to detect fishes through the image of a fish.
Fish Classifier shall be able to detect #25 Fishes.

